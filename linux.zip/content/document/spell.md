---



title: "spell命令 – 建立拼写检查程序"
description: "spell命令 – 建立拼写检查程序"
keywords: "spell命令 – 建立拼写检查程序"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

spell可从标准输入设备读取字符串，结束后显示拼错的词汇。

**语法格式：** spell [字符串]

**参考实例**

检查testfile 拼写错误 ：

```
[root@linuxcool ~]# spell testfile
```