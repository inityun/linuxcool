---



title: "ed鍛戒护 – 鏂囨湰缂栬緫"
description: "ed鍛戒护 – 鏂囨湰缂栬緫"
keywords: "ed鍛戒护 – 鏂囨湰缂栬緫"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

ed鏄?a href="https://www.linuxprobe.com/" title="Linux"target="_blank">Linux涓姛鑳芥渶绠€鍗曠殑鏂囨湰缂栬緫绋嬪簭锛屼竴娆′粎鑳界紪杈戜竴琛岃€岄潪鍏ㄥ睆骞曟柟寮忕殑鎿嶄綔銆?/p>

ed鍛戒护骞朵笉鏄竴涓父鐢ㄧ殑鍛戒护锛屼竴鑸娇鐢ㄦ瘮杈冨鐨勬槸vi 鎸囦护銆備絾ed鏂囨湰缂栬緫鍣ㄥ浜庣紪杈戝ぇ鏂囦欢鎴栧浜庡湪shell鑴氭湰绋嬪簭涓繘琛屾枃鏈紪杈戝緢鏈夌敤銆?/p>

**璇硶鏍煎紡锛?/strong>ed [鍙傛暟]**

**甯哥敤鍙傛暟锛?/strong>**

**-G 鎻愪緵鍥炲吋瀹圭殑鍔熻兘 -p 鎸囧畾ed鍦╟ommand mode鐨勬彁绀哄瓧绗?/td>-s 涓嶆墽琛屽紑鍚枃浠舵椂鐨勬鏌ュ姛鑳?--help  鏄剧ず甯姪淇℃伅 --version  鏄剧ず鐗堟湰淇℃伅**

**鍙傝€冨疄渚?/strong>**

**浠ヤ笅鏄竴涓?Linux ed 瀹屾暣瀹炰緥瑙ｆ瀽锛?/p>**

**```**
**[root@linuxcool ~]# ed**
**```**