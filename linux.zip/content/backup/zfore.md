---



title: "zfore命令 – 强制添加.gz后缀"
description: "zfore命令 – 强制添加.gz后缀"
keywords: "zfore命令 – 强制添加.gz后缀"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

zfore命令强制为gzip格式的压缩文件添加“.gz”后缀。

**语法格式：** zfore [参数]

**参考示例**

指定为test.gzip添加“.gz”后缀

```
[root@linuxcool ~]# zfore test.gzip
```