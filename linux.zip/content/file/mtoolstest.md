---



title: "mtoolstest命令 – 测试并显示mtools的相关设置"
description: "mtoolstest命令 – 测试并显示mtools的相关设置"
keywords: "mtoolstest命令 – 测试并显示mtools的相关设置"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

mtoolstest为mtools工具指令，可读取与分析mtools的配置文件，并在屏幕上显示结果 。

**语法格式：** mtoolstest

**参考实例**

在命令行中直接输入mtoolstest，即可显示mtools软件包当前的配置信息，结果如下：

```
[root@linuxcool ~]# mtoolstest
```