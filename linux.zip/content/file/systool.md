---



title: "systool命令 – 显示系统中设备的信息"
description: "systool命令 – 显示系统中设备的信息"
keywords: "systool命令 – 显示系统中设备的信息"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

systool命令指令显示基于总线、类和拓扑显示系统中设备的信息。

**语法格式：** systool [参数]

**常用参数：**

-a显示被请求资源的属性 -b显示指定总线的信息 -c显示指定类的信息 -d仅显示设备 -h显示指令的用法 -m显示指定模块的信息

**参考实例**

显示系统中设备的信息：

```
[root@linuxcool ~]# systool
```