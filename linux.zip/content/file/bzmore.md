---



title: "bzmore命令 – 查看bzip2压缩过的文本文件的内容"
description: "bzmore命令 – 查看bzip2压缩过的文本文件的内容"
keywords: "bzmore命令 – 查看bzip2压缩过的文本文件的内容"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

bzmore命令用于查看bzip2压缩过的文本文件的内容，当下一屏显示不下时可以实现分屏显示。

**语法格式：** bzmore [参数]

**参考实例**

分屏显示backup.tar.bz2压缩文件的内容：

```
[root@linuxcool ~]# bzmore backup.tar.bz2
```