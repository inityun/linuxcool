---

title: "4：磁盘管理" # 标题
description: " " # 文章描述
keywords: " " # 文章关键词
date: 2023-06-18T16:22:52+08:00 # 时间
defaultContentLanguage: "zh" # 网站语言
author: " " # 作者的名字
twitterSite: " " # Twitte用户名@bai__chang
thumbnail: " " # 文档中的其中一条图片链接
categories:  # 属于什么类型
  - Hugo
type: article # 此页面类型类型
githubURL: "https://davidpythonseo.github.io/web3blog/" # github链接
ShowToc: true
TocOpen: true

# {{< youtube XSZzxhBBzzI >}}YouTube视频引入
---

