---



title: "quotastats命令 – 显示Linux系统当前的磁盘配额运行状态信息"
description: "quotastats命令 – 显示Linux系统当前的磁盘配额运行状态信息"
keywords: "quotastats命令 – 显示Linux系统当前的磁盘配额运行状态信息"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

quotastats命令用于显示Linux系统当前的磁盘配额运行状态信息。

**语法格式：** quotastats

**参考实例**

显示磁盘配额限制状态：

```
[root@linuxcool ~]# quotastats
```