---



title: "( 红旗Linux桌面操作系统v11ARM版（0528) 更新日志"
description: "( 红旗Linux桌面操作系统v11ARM版（0528) 更新日志"
keywords: "( 红旗Linux桌面操作系统v11ARM版（0528) 更新日志"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: "https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_0.jpg"
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

![查看linux系统版本 命令_查看linux系统版本命令_linux操作系统版本命令](https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_0.jpg)

红旗Linux11是一款以“全面优化、广泛兼容、稳定可靠、智能交互”为产品最终定位的桌面操作系统发行版 **linux操作系统版本命令** linux windowslinux操作系统好吗，在后续的即将商业版本中逐渐推出包括红旗浏览器、红旗应用商店、红旗终端域管平台等大量创新的自研应用，以及与合作伙伴共同构建的红旗Office、红旗安全等重量级外置应用。

![查看linux系统版本 命令_查看linux系统版本命令_linux操作系统版本命令](https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_1.png)

更新日志：

(较上一版本，红旗Linux桌面操作系统v11ARM版（0528) 主要更新如下：

![linux操作系统版本命令_查看linux系统版本 命令_查看linux系统版本命令](https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_2.jpg)

新增支持飞腾电脑；

修补部份已知问题；

更新方式：

1.已安装红旗Linux桌面操作系统v11ARM版的用户，可参考下述方式进行系统更新。

2.未安装红旗Linux桌面操作系统v11ARM版的用户，需按下方提供的下载链接，访问红旗Linux官方社区下载版块，下载安装体验。

形式1.软件商店自定义更新

点击桌面左下角“R”图标 **linux操作系统版本命令**，点击“系统”-“软件商店”-“检查更新”，按照更新提示可自定义选定须要更新的软件包或更新全部升级的软件包。

![linux操作系统版本命令_查看linux系统版本 命令_查看linux系统版本命令](https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_3.png)

形式2.终端命令更新

更新网路源

sudoaptupdate-y查看可更新软件

aptlist--upgradable可依照需求全部或选择性的自动安装相应更新包。

![linux操作系统版本命令_查看linux系统版本 命令_查看linux系统版本命令](https://www.linuxcool.com/wp-content/uploads/2023/05/1683202259263_4.jpg)

下载链接：

END

官方站点：

Linux命令大全：