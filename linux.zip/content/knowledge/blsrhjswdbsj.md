---



title: "Babel来说：如何减少Webpack打包时间优化，影响打包效率"
description: "Babel来说：如何减少Webpack打包时间优化，影响打包效率"
keywords: "Babel来说：如何减少Webpack打包时间优化，影响打包效率"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

问题：如何减少 Webpack 打包时间

优化 Loader

对于 Loader 来说，影响打包效率首当其冲必属 Babel 了。因为 Babel 会将代码转为字符串生成 AST，然后对 AST 继续进行转变最后再生成新的代码，项目越大，转换代码越多，效率就越低。当然有办法优化。

首先我们可以优化 Loader 的文件搜索范围

```
module.exports = {
 module: {
 rules: [
 {
 // js 文件才使用 babel
 test: /.js$/,
 loader: 'babel-loader',
 // 只在 src 文件夹下查找
 include: [resolve('src')],
 // 不会去查找的路径
 exclude: /node_modules/
 }
 ]

 }
}
```

对于 Babel 来说，我们肯定是希望只作用在 JS 代码上的 **打包压缩命令linux**，然后node_modules中使用的代码都是编译过的，所以我们也完全没有必要再去处理一遍。

当然这样做还不够，我们还可以将 Babel 编译过的文件缓存起来，下次只需要编译更改过的代码文件即可，这样可以大幅度加快打包时间

```
loader: 'babel-loader?cacheDirectory=true'
```

HappyPack

受限于 Node 是单线程运行的，所以 Webpack 在打包的过程中也是单线程的，特别是在执行 Loader 的时候linux学习视频，长时间编译的任务很多，这样就会导致等待的情况。

HappyPack 可以将 Loader 的同步执行转换为并行的，这样就能充分利用系统资源来加快打包效率了

```
 loaders: [
 {
 test: /.js$/,
 include: [resolve('src')],
 exclude: /node_modules/,

 // id 后面的内容对应下面
 loader: 'happypack/loader?id=happybabel'
 }
 ]
},
plugins: [
 new HappyPack({
 id: 'happybabel',
 loaders: ['babel-loader?cacheDirectory'],
 // 开启 4 个线程
 threads: 4
 })
]
```

DllPlugin

DllPlugin 可以将特定的类库提前打包然后引入。这种方式可以极大的减少打包类库的次数，只有当类库更新版本才有需要重新打包，并且也实现了将公共代码抽离成单独文件的优化方案。

接下来我们就来学习如何使用 DllPlugin

```
// 单独配置在一个文件中
// webpack.dll.conf.js
const path = require('path')
const webpack = require('webpack')
module.exports = {
 entry: {
 // 想统一打包的类库
 vendor: ['react']
 },
 output: {
 path: path.join(__dirname, 'dist'),
 filename: '[name].dll.js',
 library: '[name]-[hash]'
 },

 plugins: [
 new webpack.DllPlugin({
 // name 必须和 output.library 一致
 name: '[name]-[hash]',
 // 该属性需要与 DllReferencePlugin 中一致
 context: __dirname,
 path: path.join(__dirname, 'dist', '[name]-manifest.json')
 })
 ]
}
```

然后我们需要执行这个配置文件生成依赖文件，接下来我们需要使用DllReferencePlugin将依赖文件引入项目中

```
// webpack.conf.js
module.exports = {
 // ...省略其他配置

 plugins: [
 new webpack.DllReferencePlugin({
 context: __dirname,
 // manifest 就是之前打包出来的 json 文件
 manifest: require('./dist/vendor-manifest.json'),
 })
 ]
}
```

代码压缩

在 Webpack3 中，我们一般使用UglifyJS来压缩代码，但是这个是单线程运行的，为了加快效率，我们可以使用webpack-parallel-uglify-plugin来并行运行UglifyJS，从而提高效率。

在 Webpack4 中，我们就不需要以上这些操作了，只需要将mode设置为production就可以默认开启以上功能。代码压缩也是我们必做的性能优化方案 **打包压缩命令linux** 永久免费linux服务器，当然我们不止可以压缩 JS 代码，还可以压缩 HTML、CSS 代码，并且在压缩 JS 代码的过程中，我们还可以通过配置实现比如删除console.log这类代码的功能。

一些小的优化点

我们还可以通过一些小的优化点来加快打包速度

resolve.extensions：用来表明文件后缀列表，默认查找顺序是[‘.js’, ‘.json’]，如果你的导入文件没有添加后缀就会按照这个顺序查找文件。我们应该尽可能减少后缀列表长度，然后将出现频率高的后缀排在前面

resolve.alias：可以通过别名的方式来映射一个路径，能让 Webpack 更快找到路径

module.noParse：如果你确定一个文件下没有其他依赖，就可以使用该属性让 Webpack 不扫描该文件，这种方式对于大型的类库很有帮助。