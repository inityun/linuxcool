---



title: "linux磁盘分区的详细步骤图解分区命令使用方法"
description: "linux磁盘分区的详细步骤图解分区命令使用方法"
keywords: "linux磁盘分区的详细步骤图解分区命令使用方法"
date: "2023-06-18T16:22:52+08:00"
defaultContentLanguage: "zh"
author: "Linux"
twitterSite: ""
thumbnail: ""
categories:
  - Linux
type: article
githubURL: "https://www.github.com/"
ShowToc: true
TocOpen: true



---

**linux硬盘分区命令** wps for linux

linuxc盘分区的详尽步骤图解linux分区命令使用方式linuxc盘分区的详尽步骤图解linux分区命令使用方式linux首先介绍下几个简单的命令free查看当前系统显存的使用情况查看分区的使用情况T类型H显示大小以GM查看系统所有硬碟的分区信息分区的没分区的都显示下来了开始分区为何要加cu不加也可以哦虚拟机做实验就要加cu针对虚拟硬碟的虚拟硬碟没柱面mforhelp按m键获得帮助参数没戏要了解这么多只晓得几个常用的就iok了d删掉分区l查看分区类型n添加分区p复印分区表q退出不保存t更改分区类型w保存一块硬碟最多可以创建4个主分区或是3个主分区一个扩充分区N个逻辑分区N代表多少我没研究过先前看书有说14的有说12还有无数的谁晓得可以留言给我一块分享其实都是主分去优先了从1开始你也可以从2开始就是看linux怎么查看系统版本

上去别扭点默认的都是2048K开始的也可以从3000K开始就是有点浪费从2直接开始忽视1分扩充分区扩充分区一般会全部吸收主分区分剩下的逻辑分区一般默认从5开始4个主分区对吧它只能从5开始更改分区类型t更改分区类型更改sdb5的8e代表lvm逻辑卷L可以查看分区类型自己可以随便选保存退出wq刷新分区表不刷新是看不到新添加的分区依然不可以使用可以看proc分区信息partprobe力度没有partx-d力度大但也可以使用分区低格选择要格式的类型以后就可以使用了扩充分区的使用低格一块swap分区先查看下当前系统中的swap分区信息添加一块swap分区同时也可以看sda2的优先级小于sdb5数字越大优先级越高关掉一块swap分区不想要这块swap分区了swap分区已关掉一格式化或是直接从分区中删掉linux **linux硬盘分区命令**